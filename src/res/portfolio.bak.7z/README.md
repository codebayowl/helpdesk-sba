# Portfolio on CodeBay
Portfolio page will be a part of blog - codebay or codebayowl
It will consists of:
- about section;
- design section (with raster & vector design graphics);
- photo gallery (panorams);
- front- and backend works;
- contact form;
- footer with social media links;
